import React from 'react';
import Navbar from './components/Navbar';
import Login from './components/Login';
import Dashboard from './components/Dashboard';

function App(){
  return (
    <div>
      <Navbar />
      <main style={{padding: '20px'}}>
        {/* Swap components based on auth state - placeholder */}
        <Login />
        {/* <Dashboard /> */}
      </main>
    </div>
  );
}

export default App;
