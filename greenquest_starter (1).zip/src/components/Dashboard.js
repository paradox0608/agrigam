import React from 'react';

export default function Dashboard(){
  return (
    <div className="container">
      <h1>Dashboard</h1>
      <div style={{display:'grid', gridTemplateColumns:'1fr 320px', gap:20}}>
        <div>
          <div className="card"><h3>Active Challenges</h3></div>
          <div className="card" style={{marginTop:12}}><h3>Lessons</h3></div>
        </div>
        <aside>
          <div className="card"><h3>Leaderboard</h3></div>
          <div className="card" style={{marginTop:12}}><h3>Profile</h3></div>
        </aside>
      </div>
    </div>
  );
}
