import React from 'react';

export default function Leaderboard(){
  return (
    <div className="card">
      <h3>Leaderboard</h3>
      <ol>
        <li>Farmer A — 120 pts</li>
        <li>Farmer B — 95 pts</li>
        <li>Farmer C — 80 pts</li>
      </ol>
    </div>
  );
}
