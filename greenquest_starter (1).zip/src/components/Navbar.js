import React from 'react';

export default function Navbar(){
  return (
    <nav>
      <div className="container">
        <strong>GreenQuest</strong>
      </div>
      <div style={{marginRight:20}}>
        <input placeholder="Search schemes, lessons..." style={{padding:6, marginRight:8}} />
        <button>🎤</button>
        <select aria-label="language">
          <option value="en">English</option>
          <option value="hi">हिन्दी</option>
        </select>
        <button style={{marginLeft:8}}>Login</button>
      </div>
    </nav>
  );
}
