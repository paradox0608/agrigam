import React from 'react';

export default function Challenges(){
  return (
    <div className="card">
      <h3>Challenges</h3>
      <ul>
        <li>Use organic compost — 10 pts <button>Mark Done</button></li>
        <li>Save water for 7 days — 20 pts <button>Mark Done</button></li>
      </ul>
    </div>
  );
}
