import React, {useState} from 'react';
import axios from 'axios';

/*
  Simple Chatbot UI placeholder.
  Integrate with OpenAI / other AI provider backend to keep API keys safe.
*/
export default function ChatbotAI(){
  const [q, setQ] = useState('');
  const [resp, setResp] = useState('');

  const askAI = async () => {
    // Call your serverless function that queries the AI model
    setResp('Sample response: Use compost to improve soil organic matter.');
  };

  return (
    <div className="card">
      <h3>AI Advisor</h3>
      <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Ask about your crop or soil" style={{width:'100%',padding:8}}/>
      <button onClick={askAI} style={{marginTop:8}}>Ask</button>
      <div style={{marginTop:12}}>{resp}</div>
    </div>
  );
}
