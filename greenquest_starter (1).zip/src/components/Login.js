import React from 'react';

/* Placeholder Login component.
   Replace with Firebase Auth integration. */
export default function Login(){
  return (
    <div className="container">
      <div className="card" style={{maxWidth:480, margin:'40px auto'}}>
        <h2>Login / Signup</h2>
        <p>Placeholder — integrate Firebase Auth</p>
        <input placeholder="Email" style={{display:'block',width:'100%',padding:8,marginBottom:8}}/>
        <input placeholder="Password" type="password" style={{display:'block',width:'100%',padding:8,marginBottom:8}}/>
        <button style={{padding:8}}>Login</button>
      </div>
    </div>
  );
}
