# GreenQuest — Starter Skeleton (React + Firebase)

This starter contains a minimal React + Firebase skeleton tailored for the GreenQuest gamified sustainable farming app.
Placeholders are provided for Firebase config, AI keys, and translations.

## What's included
- package.json (dependencies)
- public/index.html
- src/
  - index.js
  - App.js
  - firebaseConfig.js (placeholder)
  - i18n.js (i18next setup)
  - components/
    - Login.js
    - Dashboard.js
    - Leaderboard.js
    - Challenges.js
    - ChatbotAI.js
    - Navbar.js
  - styles.css

## How to run (locally)
1. Install dependencies:
   npm install
2. Add your Firebase config in src/firebaseConfig.js
3. Start app:
   npm start

## Notes
- This is a skeleton for hackathon speed. Integrate Firebase Auth, Firestore and OpenAI (or your AI provider) as needed.
