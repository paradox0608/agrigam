# System Architecture (Text + Mermaid)

## Components
- Client (React web / mobile web)
  - Navbar (search, mic, language selector)
  - Dashboard, Challenges, Lessons, Leaderboard, Profile, Community
  - Chatbot UI (text + voice)
- Firebase
  - Auth (Email/Google)
  - Firestore (users, tasks, completions, schemes)
  - Hosting (optional)
- AI Layer
  - Serverless API (Node/Python) that proxies to OpenAI / other model
  - Translation / i18n microservice
- External APIs
  - WeatherAPI / Agmarknet / AgriStack / Soil Health data
- Optional IoT / Sensors
  - Soil sensors → ingestion pipeline

## Mermaid Diagram (paste into a mermaid renderer to visualize)
```mermaid
flowchart LR
  subgraph Client
    A[React App<br/>Search + Mic + Lang] --> B[Dashboard]
    A --> C[Challenges]
    A --> D[Chatbot UI]
  end

  subgraph Firebase
    FAuth[Auth] --> FUsers[(Users Collection)]
    FTasks[(Tasks Collection)]
    FLeaderboard[(Leaderboard View)]
    FStorage[(Storage)]
  end

  D -->|AI Request| AI[Serverless AI Proxy]
  AI -->|calls| OpenAI[(OpenAI / LLM)]
  AI -->|translates| Translate[(Translation Service)]

  B --> Firebase
  C --> Firebase
  D --> Firebase
  B --> External[External APIs (Weather/Agmarknet/Soil)]
  External -->|data| Firebase

  IoT[Soil Sensors] -->|push| External
  AI --> Firebase

```
